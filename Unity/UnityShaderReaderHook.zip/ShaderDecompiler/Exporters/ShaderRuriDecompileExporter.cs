using System.Text;
using AssetRipper.Assets;
using AssetRipper.Assets.Generics;
using AssetRipper.Export.Modules.Shaders.Extensions;
using AssetRipper.Export.Modules.Shaders.ShaderBlob;
using AssetRipper.Export.UnityProjects;
using AssetRipper.Export.UnityProjects.Shaders;
using AssetRipper.IO.Files;
using AssetRipper.Primitives;
using AssetRipper.SourceGenerated.Classes.ClassID_48;
using AssetRipper.SourceGenerated.Extensions.Enums.Shader;
using AssetRipper.SourceGenerated.Extensions.Enums.Shader.GpuProgramType;
using AssetRipper.SourceGenerated.Subclasses.SerializedPass;
using AssetRipper.SourceGenerated.Subclasses.SerializedPlayerSubProgram;
using AssetRipper.SourceGenerated.Subclasses.SerializedProgram;
using AssetRipper.SourceGenerated.Subclasses.SerializedProgramParameters;
using AssetRipper.SourceGenerated.Subclasses.SerializedSubProgram;
using Newtonsoft.Json;
using Ruri.RipperHook;
using Ruri.RipperHook.Endfield;
using Ruri.ShaderTools;

namespace Ruri.RipperHook.AR;

public sealed class ShaderRuriDecompileExporter : ShaderExporterBase
{
    public override bool Export(IExportContainer container, IUnityObjectBase asset, string path, FileSystem fileSystem)
    {
        IShader shader = (IShader)asset;
        List<DecompiledBlock> blocks = DecompileShader(shader, GPUPlatform.D3D11);
        if (blocks.Count == 0)
        {
            return false;
        }

        using Stream fileStream = File.Create(path);
        using StreamWriter writer = new StreamWriter(fileStream, new UTF8Encoding(false));
        writer.Write(BuildOutput(shader, blocks));
        WriteMetadataSidecar(path, blocks);
        return true;
    }

    private static List<DecompiledBlock> DecompileShader(IShader shader, GPUPlatform platform)
    {
        if (shader.ParsedForm is null)
        {
            return [];
        }

        ShaderSubProgramBlob[] blobs = shader.ReadBlobs();
        if (blobs.Length == 0)
        {
            return [];
        }

        List<ShaderReadPass> reads = ReadPasses(shader, blobs, platform);
        if (reads.Count == 0)
        {
            return [];
        }

        List<ShaderSymbolPass> symbols = BuildSymbols(reads);
        using ShaderDecompiler decompiler = new(AppDomain.CurrentDomain.BaseDirectory);
        return DecompilePasses(symbols, decompiler);
    }

    private static List<ShaderReadPass> ReadPasses(IShader shader, ShaderSubProgramBlob[] blobs, GPUPlatform platform)
    {
        List<int> platformValues = shader.Platforms?.Select(p => (int)p).ToList() ?? [];
        int selectedPlatformIndex = platformValues.FindIndex(p => p == (int)platform);
        if (selectedPlatformIndex < 0 || selectedPlatformIndex >= blobs.Length)
        {
            return [];
        }

        ShaderSubProgramBlob blob = blobs[selectedPlatformIndex];
        List<ShaderReadPass> result = [];
        for (int subShaderIndex = 0; subShaderIndex < shader.ParsedForm!.SubShaders.Count; subShaderIndex++)
        {
            var subShader = shader.ParsedForm.SubShaders[subShaderIndex];
            for (int passIndex = 0; passIndex < subShader.Passes.Count; passIndex++)
            {
                var pass = subShader.Passes[passIndex];
                Dictionary<int, string> nameTable = BuildNameTable(pass.NameIndices);
                ReadProgram(shader, blob, pass, pass.ProgVertex, ShaderGpuProgramType.DX11VertexSM40, subShaderIndex, passIndex, nameTable, result);
                ReadProgram(shader, blob, pass, pass.ProgVertex, ShaderGpuProgramType.DX11VertexSM50, subShaderIndex, passIndex, nameTable, result);
                ReadProgram(shader, blob, pass, pass.ProgFragment, ShaderGpuProgramType.DX11PixelSM40, subShaderIndex, passIndex, nameTable, result);
                ReadProgram(shader, blob, pass, pass.ProgFragment, ShaderGpuProgramType.DX11PixelSM50, subShaderIndex, passIndex, nameTable, result);
                ReadProgram(shader, blob, pass, pass.ProgGeometry, ShaderGpuProgramType.DX11GeometrySM40, subShaderIndex, passIndex, nameTable, result);
                ReadProgram(shader, blob, pass, pass.ProgGeometry, ShaderGpuProgramType.DX11GeometrySM50, subShaderIndex, passIndex, nameTable, result);
                ReadProgram(shader, blob, pass, pass.ProgHull, ShaderGpuProgramType.DX11HullSM50, subShaderIndex, passIndex, nameTable, result);
                ReadProgram(shader, blob, pass, pass.ProgDomain, ShaderGpuProgramType.DX11DomainSM50, subShaderIndex, passIndex, nameTable, result);
                ReadProgram(shader, blob, pass, pass.ProgRayTracing, ShaderGpuProgramType.RayTracing, subShaderIndex, passIndex, nameTable, result);
            }
        }

        return result;
    }

    private static void ReadProgram(
        IShader shader,
        ShaderSubProgramBlob blob,
        ISerializedPass pass,
        ISerializedProgram? program,
        ShaderGpuProgramType expectedType,
        int subShaderIndex,
        int passIndex,
        Dictionary<int, string> nameTable,
        List<ShaderReadPass> result)
    {
        if (program is null)
        {
            return;
        }

        foreach (ShaderReadSource source in EnumerateProgramSources(program, shader.Collection.Version, expectedType))
        {
            ShaderSubProgram subProgram = source.ParameterBlobIndex is uint paramBlobIndex
                ? blob.GetSubProgram(source.BlobIndex, paramBlobIndex)
                : blob.GetSubProgram(source.BlobIndex);

            if (subProgram.ProgramData.Length == 0)
            {
                continue;
            }

            byte[] dxbc = ExtractDxbcPayload(subProgram.ProgramData, shader.Collection.Version, GPUPlatform.D3D11);
            if (dxbc.Length == 0)
            {
                continue;
            }

            result.Add(new ShaderReadPass(
                pass.State.Name_R,
                subShaderIndex,
                passIndex,
                source.BlobIndex,
                subProgram,
                ReadProgramSymbols(program.CommonParameters, nameTable),
                ReadProgramSymbols(source.Parameters, nameTable),
                dxbc,
                shader.Name,
                shader.Collection.Version));
        }
    }

    private static IEnumerable<ShaderReadSource> EnumerateProgramSources(ISerializedProgram program, UnityVersion version, ShaderGpuProgramType expectedType)
    {
        Dictionary<uint, ISerializedSubProgram> subProgramsByBlob = new();
        foreach (ISerializedSubProgram subProgram in program.SubPrograms)
        {
            subProgramsByBlob[subProgram.BlobIndex] = subProgram;
        }

        if (program.Has_PlayerSubPrograms() && program.Has_ParameterBlobIndices() && program.PlayerSubPrograms is not null && program.ParameterBlobIndices is not null)
        {
            for (int groupIndex = 0; groupIndex < program.PlayerSubPrograms.Count; groupIndex++)
            {
                AssetList<SerializedPlayerSubProgram> group = program.PlayerSubPrograms[groupIndex];
                if (group.Count == 0)
                {
                    continue;
                }

                AssetList<uint>? paramGroup = groupIndex < program.ParameterBlobIndices.Count ? program.ParameterBlobIndices[groupIndex] : null;
                for (int i = 0; i < group.Count; i++)
                {
                    SerializedPlayerSubProgram playerSubProgram = group[i];
                    if (!MatchesProgramType(version, playerSubProgram.GpuProgramType, expectedType))
                    {
                        continue;
                    }

                    subProgramsByBlob.TryGetValue(playerSubProgram.BlobIndex, out ISerializedSubProgram? sourceSubProgram);
                    yield return new ShaderReadSource(
                        playerSubProgram.BlobIndex,
                        paramGroup is not null && i < paramGroup.Count ? paramGroup[i] : null,
                        sourceSubProgram?.Has_Parameters() == true ? sourceSubProgram.Parameters : null);
                }
            }
        }

        foreach (ISerializedSubProgram subProgram in program.SubPrograms)
        {
            if (!MatchesProgramType(version, (sbyte)subProgram.GpuProgramType, expectedType))
            {
                continue;
            }

            yield return new ShaderReadSource(
                subProgram.BlobIndex,
                null,
                subProgram.Has_Parameters() ? subProgram.Parameters : null);
        }
    }

    private static ShaderSymbolData ReadProgramSymbols(ISerializedProgramParameters? parameters, Dictionary<int, string> nameTable)
    {
        ShaderSymbolData data = new();
        if (parameters is null)
        {
            return data;
        }

        Func<int, string> resolveName = nameIndex => nameTable.TryGetValue(nameIndex, out string? name) ? name : $"name_{nameIndex}";

        foreach (var cbuffer in parameters.ConstantBuffers)
        {
            ConstantBuffer buffer = new()
            {
                Name = resolveName(cbuffer.NameIndex),
                NameIndex = cbuffer.NameIndex,
                Size = cbuffer.Size,
                IsPartialCB = cbuffer.Has_IsPartialCB() && cbuffer.IsPartialCB,
                MatrixParams = cbuffer.MatrixParams.Select(matrix => new MatrixParameter
                {
                    Name = resolveName(matrix.NameIndex),
                    NameIndex = matrix.NameIndex,
                    ByteOffset = matrix.Index,
                    ArraySize = matrix.ArraySize,
                    Type = (Ruri.ShaderTools.ShaderParamType)(int)(sbyte)matrix.Type,
                    RowCount = unchecked((byte)matrix.RowCount),
                    ColumnCount = 4,
                    IsMatrix = true,
                }).ToArray(),
                VectorParams = cbuffer.VectorParams.Select(vector => new VectorParameter
                {
                    Name = resolveName(vector.NameIndex),
                    NameIndex = vector.NameIndex,
                    ByteOffset = vector.Index,
                    ArraySize = vector.ArraySize,
                    Type = (Ruri.ShaderTools.ShaderParamType)(int)(sbyte)vector.Type,
                    RowCount = unchecked((byte)vector.Dim),
                    ColumnCount = 1,
                    IsMatrix = false,
                }).ToArray(),
                StructParams = cbuffer.StructParams.Select(structParam => new StructParameter
                {
                    Name = resolveName(structParam.NameIndex),
                    NameIndex = structParam.NameIndex,
                    Index = structParam.Index,
                    ArraySize = structParam.ArraySize,
                    StructSize = structParam.StructSize,
                    MatrixMembers = structParam.MatrixMembers.Select(matrix => new MatrixParameter
                    {
                        Name = $"{resolveName(structParam.NameIndex)}.{resolveName(matrix.NameIndex)}",
                        NameIndex = matrix.NameIndex,
                        ByteOffset = matrix.Index,
                        ArraySize = matrix.ArraySize,
                        Type = (Ruri.ShaderTools.ShaderParamType)(int)(sbyte)matrix.Type,
                        RowCount = unchecked((byte)matrix.RowCount),
                        ColumnCount = 4,
                        IsMatrix = true,
                    }).ToArray(),
                    VectorMembers = structParam.VectorMembers.Select(vector => new VectorParameter
                    {
                        Name = $"{resolveName(structParam.NameIndex)}.{resolveName(vector.NameIndex)}",
                        NameIndex = vector.NameIndex,
                        ByteOffset = vector.Index,
                        ArraySize = vector.ArraySize,
                        Type = (Ruri.ShaderTools.ShaderParamType)(int)(sbyte)vector.Type,
                        RowCount = unchecked((byte)vector.Dim),
                        ColumnCount = 1,
                        IsMatrix = false,
                    }).ToArray(),
                }).ToArray(),
            };
            data.ConstantBuffers.Add(buffer);
        }

        foreach (var binding in parameters.ConstantBufferBindings)
        {
            data.ConstantBufferBindings.Add(new BufferBinding
            {
                Name = resolveName(binding.NameIndex),
                NameIndex = binding.NameIndex,
                Index = binding.Index,
                Set = 0,
                ArraySize = binding.Has_ArraySize() ? binding.ArraySize : 0,
            });
        }

        foreach (var texture in parameters.TextureParams)
        {
            data.TextureParameters.Add(new TextureParameter
            {
                Name = resolveName(texture.NameIndex),
                NameIndex = texture.NameIndex,
                Index = texture.Index,
                Set = 0,
                SamplerIndex = texture.SamplerIndex,
                MultiSampled = texture.Has_MultiSampled() && texture.MultiSampled,
                Dim = unchecked((byte)(sbyte)texture.Dim),
            });
        }

        foreach (var sampler in parameters.Samplers)
        {
            data.Samplers.Add(new SamplerParameter
            {
                Sampler = sampler.Sampler,
                Index = sampler.BindPoint,
                Set = 0,
            });
        }

        foreach (var uav in parameters.UAVParams)
        {
            data.UAVs.Add(new UAVParameter
            {
                Name = resolveName(uav.NameIndex),
                NameIndex = uav.NameIndex,
                Index = uav.Index,
                Set = 0,
                OriginalIndex = uav.OriginalIndex,
            });
        }

        return data;
    }

    private static List<ShaderSymbolPass> BuildSymbols(List<ShaderReadPass> reads)
    {
        List<ShaderSymbolPass> result = [];
        foreach (ShaderReadPass read in reads)
        {
            ShaderSymbolData symbols = new()
            {
                EntryPoint = "main",
                DebugName = $"{read.ShaderName}/SubShader{read.SubShaderIndex}/Pass{read.PassIndex}/{read.SubProgram.GetProgramType(read.Version)}/{read.BlobIndex}",
            };

            AppendSymbols(symbols, read.CommonSymbols, decode: true);
            AppendSymbols(symbols, read.ParameterSymbols, decode: true);
            AppendRuntimeSymbols(symbols, read.SubProgram);
            result.Add(new ShaderSymbolPass(read, symbols));
        }

        return result;
    }

    private static List<DecompiledBlock> DecompilePasses(List<ShaderSymbolPass> symbols, ShaderDecompiler decompiler)
    {
        List<DecompiledBlock> result = [];
        foreach (ShaderSymbolPass pass in symbols)
        {
            DecompileResult decompiled = decompiler.Decompile(pass.Read.Dxbc, ShaderArchitecture.Dxbc, pass.Symbols, 50);
            result.Add(new DecompiledBlock(
                pass.Read.PassName,
                pass.Read.SubShaderIndex,
                pass.Read.PassIndex,
                pass.Read.BlobIndex,
                pass.Symbols,
                decompiled.Success ? decompiled.SourceCode ?? string.Empty : string.Empty,
                decompiled.ErrorMessage,
                pass.Read.Dxbc));
        }

        return result;
    }

    private static void AppendSymbols(ShaderSymbolData target, ShaderSymbolData source, bool decode)
    {
        foreach (ConstantBuffer buffer in source.ConstantBuffers)
        {
            target.ConstantBuffers.Add(buffer);
        }

        foreach (BufferBinding binding in source.ConstantBufferBindings)
        {
            if (!decode)
            {
                target.ConstantBufferBindings.Add(binding);
                continue;
            }

            (int index, int set) = DecodeUnityBindPoint(binding.Index);
            target.ConstantBufferBindings.Add(new BufferBinding
            {
                Name = binding.Name,
                NameIndex = binding.NameIndex,
                Index = index,
                Set = set,
                ArraySize = binding.ArraySize,
            });
        }

        foreach (TextureParameter texture in source.TextureParameters)
        {
            if (!decode)
            {
                target.TextureParameters.Add(texture);
                continue;
            }

            (int index, int set) = DecodeUnityBindPoint(texture.Index);
            target.TextureParameters.Add(new TextureParameter
            {
                Name = texture.Name,
                NameIndex = texture.NameIndex,
                Index = index,
                Set = set,
                SamplerIndex = DecodeUnityBindPoint(texture.SamplerIndex).Binding,
                MultiSampled = texture.MultiSampled,
                Dim = texture.Dim,
            });
        }
    }

    private static void AppendRuntimeSymbols(ShaderSymbolData target, ShaderSubProgram subProgram)
    {
        if (EndFieldCommon_Hook.IsEndFieldActive() && subProgram.DescriptorSetParams.Length > 0)
        {
            EndFieldShaderSymbolExtensions.AppendRuntimeSymbols(target, subProgram);
            return;
        }

        foreach (ConstantBuffer buffer in subProgram.ConstantBuffers)
        {
            target.ConstantBuffers.Add(buffer);
        }

        foreach (BufferBinding binding in subProgram.ConstantBufferBindings)
        {
            target.ConstantBufferBindings.Add(binding);
        }

        foreach (TextureParameter texture in subProgram.TextureParameters)
        {
            target.TextureParameters.Add(texture);
        }

        foreach (SamplerParameter sampler in subProgram.SamplerParameters)
        {
            target.Samplers.Add(sampler);
        }

        foreach (UAVParameter uav in subProgram.UAVParameters)
        {
            target.UAVs.Add(uav);
        }
    }

    private static Dictionary<int, string> BuildNameTable(AccessDictionaryBase<Utf8String, int> nameIndices)
    {
        Dictionary<int, string> table = new(nameIndices.Count);
        for (int i = 0; i < nameIndices.Count; i++)
        {
            var pair = nameIndices.GetPair(i);
            table[pair.Value] = pair.Key.ToString();
        }
        return table;
    }

    private static byte[] ExtractDxbcPayload(byte[] programData, UnityVersion version, GPUPlatform platform)
    {
        if (programData.Length == 0)
        {
            return [];
        }

        int headerVersion = programData[0];
        int offset = GetDirectXDataOffset(version, platform, headerVersion);
        if (offset < 0 || offset >= programData.Length)
        {
            return [];
        }

        byte[] trimmed = new byte[programData.Length - offset];
        Buffer.BlockCopy(programData, offset, trimmed, 0, trimmed.Length);
        return trimmed;
    }

    private static int GetDirectXDataOffset(UnityVersion version, GPUPlatform platform, int headerVersion)
    {
        if (platform == GPUPlatform.D3D9)
        {
            return 0;
        }

        int offset = version.GreaterThanOrEquals(5, 4) ? 6 : 5;
        if (headerVersion >= 2)
        {
            offset += 0x20;
        }
        return offset;
    }

    private static string BuildOutput(IShader shader, List<DecompiledBlock> blocks)
    {
        StringBuilder sb = new();
        sb.AppendLine($"// Shader: {shader.Name}");
        sb.AppendLine("// Decompiled by ShaderRuriDecompileExporter");

        foreach (DecompiledBlock block in blocks)
        {
            sb.AppendLine();
            sb.AppendLine($"// SubShader {block.SubShaderIndex}, Pass {block.PassIndex}, Blob {block.BlobIndex}");
            sb.AppendLine($"// PassName: {block.PassName}");
            if (!string.IsNullOrWhiteSpace(block.ErrorMessage))
            {
                sb.AppendLine($"// DecompileError: {block.ErrorMessage}");
            }

            if (string.IsNullOrWhiteSpace(block.Source))
            {
                sb.AppendLine("// No decompiled source generated.");
            }
            else
            {
                sb.AppendLine(block.Source.TrimEnd());
            }
        }

        return sb.ToString();
    }

    private static void WriteMetadataSidecar(string outputPath, List<DecompiledBlock> blocks)
    {
        foreach (DecompiledBlock block in blocks)
        {
            string basePath = $"{outputPath}.sub{block.SubShaderIndex}.pass{block.PassIndex}.blob{block.BlobIndex}.{SanitizeFileName(block.PassName)}";
            File.WriteAllText($"{basePath}.metadata.json", JsonConvert.SerializeObject(block.Metadata, Formatting.Indented), new UTF8Encoding(false));
            File.WriteAllBytes($"{basePath}.dxbc.bin", block.Dxbc);
        }
    }

    private static string SanitizeFileName(string value)
    {
        char[] invalidChars = Path.GetInvalidFileNameChars();
        StringBuilder builder = new(value.Length);
        foreach (char c in value)
        {
            builder.Append(invalidChars.Contains(c) ? '_' : c);
        }
        return builder.ToString();
    }

    private static bool MatchesProgramType(UnityVersion version, sbyte rawType, ShaderGpuProgramType expectedType)
    {
        return ToRuriProgramType(ToUnityProgramType(version, rawType)).IsMatch(ToRuriProgramType(expectedType));
    }

    private static ShaderGpuProgramType ToUnityProgramType(UnityVersion version, sbyte rawType)
    {
        if (ShaderGpuProgramTypeExtensions.GpuProgramType55Relevant(version))
        {
            return ((ShaderGpuProgramType55)(int)rawType).ToGpuProgramType();
        }

        return ((ShaderGpuProgramType53)(int)rawType).ToGpuProgramType();
    }

    private static Ruri.ShaderTools.RuriShaderGpuProgramType ToRuriProgramType(ShaderGpuProgramType type)
    {
        return (Ruri.ShaderTools.RuriShaderGpuProgramType)(int)type;
    }

    private static (int Binding, int Set) DecodeUnityBindPoint(int bindPoint)
    {
        if (bindPoint < 0)
        {
            return (-1, 0);
        }

        uint raw = unchecked((uint)bindPoint);
        uint logical = (raw << 16)
            | (((raw & 0x1F0000)
            | (((raw & 0x1800000)
            | (((raw & 0x2000000)
            | (((raw >> 6) | (raw & 0x7C000000)) >> 6)) >> 3)) >> 11)) >> 5);
        return (unchecked((int)(logical >> 16)), (int)((logical >> 11) & 0x1Fu));
    }

    private sealed record ShaderReadSource(uint BlobIndex, uint? ParameterBlobIndex, ISerializedProgramParameters? Parameters);

    private sealed record ShaderReadPass(
        string PassName,
        int SubShaderIndex,
        int PassIndex,
        uint BlobIndex,
        ShaderSubProgram SubProgram,
        ShaderSymbolData CommonSymbols,
        ShaderSymbolData ParameterSymbols,
        byte[] Dxbc,
        string ShaderName,
        UnityVersion Version);

    private sealed record ShaderSymbolPass(ShaderReadPass Read, ShaderSymbolData Symbols);

    private sealed record DecompiledBlock(
        string PassName,
        int SubShaderIndex,
        int PassIndex,
        uint BlobIndex,
        ShaderSymbolData Metadata,
        string Source,
        string? ErrorMessage,
        byte[] Dxbc);
}
